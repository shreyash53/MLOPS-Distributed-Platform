from flask_sqlalchemy import SQLAlchemy
# from flask_session import Session

db = SQLAlchemy()
# session_obj = Session()